import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        Scanner bind = new Scanner(System.in);

        Estudante estudante = new Estudante();

        System.out.println("Entre com as informações do Estudante");
        System.out.print("Nome: ");
        estudante.nome = bind.nextLine();
        System.out.print("Nota 1: ");
        estudante.nota1 = bind.nextDouble();
        System.out.print("Nota 2: ");
        estudante.nota2 = bind.nextDouble();
        System.out.print("Nota 3:" );
        estudante.nota3 = bind.nextDouble();

        System.out.printf("Nota Final: %.2f%n", estudante.notaFinal());

        if (estudante.notaFinal() < 70.0){
            System.out.println("Reprovado");
            System.out.printf("Falta %.2f ponto(s)%n", estudante.verificacao());

        }else{

            System.out.println("Aprovado");
        }



    }
}