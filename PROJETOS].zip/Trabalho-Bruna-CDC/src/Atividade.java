import java.util.Scanner;

public class Atividade {

    static Scanner bind = new Scanner(System.in);

    static int x;

    static int y;

    static int z;

    public static void funcao1() {

        System.out.println("Para verdadeiro digite 1");
        System.out.println("Para  falso   digite   0");
        System.out.println();
        System.out.print("Digite o valor lógico de A: ");

        x = bind.nextInt();

        System.out.print("Digite o valor lógico de B: ");

        y = bind.nextInt();

        System.out.println("Agora nos informe qual operação lógica você quer executar");
        System.out.println("1 para E ");
        System.out.println("2 para OU ");
        System.out.println("3 para Condicional");
        System.out.println();
        System.out.print("Digite o valor o tipo de operação que você escolheu: ");

        z = bind.nextInt();


        if (z == 1) {

            if ((x == 1 & y == 1)) {

                System.out.println("A combinação de A e B é verdadeiro");

            } else if ((x == 0 & y == 0)) {

                System.out.println("A combinação de A e B é falso");

            } else if (x == 1 & y == 0) {

                System.out.println("A combinação de A e B é falso");

            } else if (x == 0 & y == 1) {

                System.out.println("A combinação de A e B é falso");

            }
        }

        // public static void funcao2()

        if (z == 2) {
            if ((x == 1 & y == 1)) {

                System.out.println("A combinação de A ou B é verdadeiro");

            } else if ((x == 0 & y == 0)) {

                System.out.println("A combinação de A ou B é falso");

            } else if (x == 1 & y == 0) {

                System.out.println("A combinação de A ou B é verdadeiro");

            } else if (x == 0 & y == 1) {

                System.out.println("A combinação de A ou B é verdadeiro");

            }
        }

        //public static void funcao3


        if (z == 3) {
            if ((x == 1 & y == 1)) {

                System.out.println("A combinação de A condional B é verdadeiro");

            } else if ((x == 0 & y == 0)) {

                System.out.println("A combinação de A condicional B é Verdadeiro");

            } else if (x == 1 & y == 0) {

                System.out.println("A combinação de A condicional B é falso");

            } else if (x == 0 & y == 1) {

                System.out.println("A combinação de A condicional B é verdadeiro");

            }
        }
    }

    public static void main(String[] args) {

            funcao1();
    }

}



