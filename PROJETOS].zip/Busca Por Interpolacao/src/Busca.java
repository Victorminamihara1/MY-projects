public class Busca{
    public static int busca(int[] array, int alvo) {
        int baixo = 0;
        int alto = array.length - 1;

        while (baixo <= alto && alvo >= array[baixo] && alvo <= array[alto]) {

            int pos = baixo + ((alvo - array[baixo]) * (alto - baixo)) / (array[alto] - array[baixo]);

            if (array[pos] == alvo) {
                return pos;
            } else if (array[pos] < alvo) {
                baixo = pos + 1;
            } else {
                alto = pos - 1;
            }
        }

        return -1;
    }

    public static void main(String[] args) {
        int[] array = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
        int alvo = 50;
        int indice = busca(array, alvo);

        if (indice != -1) {
            System.out.println("Elemento encontrado no índice: " + indice);
        } else {
            System.out.println("Elemento não encontrado no array.");
        }
    }
}