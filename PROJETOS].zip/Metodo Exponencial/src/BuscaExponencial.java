public class BuscaExponencial {
    public static int busca(int[] array, int alvo) {
        int tamanho = array.length;
        if (array[0] == alvo) {
            return 0;
        }
        int i = 1;
        while (i < tamanho && array[i] <= alvo) {
            i *= 2;
        }
        return buscaBinaria(array, alvo, i / 2, Math.min(i, tamanho));
    }
    private static int buscaBinaria(int[] array, int alvo, int inicio, int fim) {
        while (inicio <= fim) {
            int meio = inicio + (fim - inicio) / 2;

            if (array[meio] == alvo) {
                return meio;
            } else if (array[meio] < alvo) {
                inicio = meio + 1;
            } else {
                fim = meio - 1;
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        int[] array = {2, 3, 4, 10, 40};
        int alvo = 10;
        int indice = busca(array, alvo);
        if (indice != -1) {
            System.out.println("Elemento encontrado no índice: " + indice);
        } else {
            System.out.println("Elemento não encontrado no array.");
        }
    }
}