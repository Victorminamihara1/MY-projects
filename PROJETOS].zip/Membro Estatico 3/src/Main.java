import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        Scanner bind = new Scanner(System.in);
        //Calculadora calc = new Calculadora();

        System.out.println("Entre com a medida do raio: ");
        double r = bind.nextDouble();

        double circ = Calculadora.circuferencia(r);
        double vol = Calculadora.volume(r);// Da par retornar o resultado cirando o variavel para
        //pegar o valor do return


        System.out.printf("A circuferencia é: %.2f%n", circ);
        System.out.printf("Volume da esfera é: %.2f%n", vol);
        System.out.printf("Valor do PI é: %.2f%n", Calculadora.PI);

    }

}