import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner bind = new Scanner(System.in);

        Banco banco;

        System.out.println("Informe o numero da conta: ");
        int numero = bind.nextInt();
        System.out.println("Informe o titular da conta: ");
        String nome = bind.next();
        System.out.println("Possui depósito inicial? (s/n)");
        char resposta = bind.next().charAt(0);

        if (resposta == 's' || resposta == 'S'){
            System.out.println("Qual valor do depósito: ");
            double depositoIncial = bind.nextDouble();
            banco = new Banco(numero, nome, depositoIncial);
        }else{
            banco = new Banco(numero, nome);
        }
        System.out.println("Dados da Conta: \n" + banco);

        System.out.println("Informe o valor de depósito: ");
        double valorDeposito = bind.nextDouble();
        banco.deposito(valorDeposito);
        System.out.println();
        System.out.println("Dados da Conta: \n" + banco);
        System.out.println();
        System.out.println("Informe o valor do Saque");
        double valorSaque = bind.nextDouble();
        banco.saque(valorSaque);

        System.out.println();
        System.out.println("Dadaos Atulizados: \n" + banco);
    }
}
