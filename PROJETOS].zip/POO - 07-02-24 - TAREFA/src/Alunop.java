import java.lang.reflect.GenericArrayType;
import java.util.Scanner;

public class Alunop{

    String nome;
    int idade;
    String genero;

    int data;

    Scanner bind = new Scanner(System.in);

    void inserirInformacoes(){

        System.out.println("Nome:");
        nome = bind.nextLine();
        System.out.println("Idade: ");
        idade = bind.nextInt();
        System.out.println("Genero");
        genero = bind.next();
    }
    void mostrarInformacoes(){

        System.out.println("Nome: "+nome);
        System.out.println("Idade: "+idade);
        System.out.println("Genero: "+genero);

    }

    void calcularDataDeNascimento(){

        data = 2024 - idade;
        System.out.println("Ano de nascimento: "+data);
    }


}
