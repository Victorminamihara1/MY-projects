
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner bind = new Scanner(System.in);

        System.out.println("OOOOO CARRO");
        System.out.print("Quantidade de Gasolina em litros: ");
        Carro.tanque = bind.nextInt();
        System.out.print("Velocidade do veículo em Km: ");
        Carro.velocidade = bind.nextInt();
        System.out.print("Distância percorrida em Km: ");
        Carro.distancia = bind.nextDouble();
        System.out.print("Tempo da viagem em Horas: ");
        Carro.tempo = bind.nextDouble();

        int opcao = 0;

        while(opcao != 9){
            System.out.println("1 - Para ver Status do Carro");
            System.out.println("2 - Para Ligar o motor");
            System.out.println("3 - Para Desligar o motor");
            System.out.println("4 - Para Andar com o carro");
            System.out.println("5 - Para Parar o carro");
            System.out.println("6 - Para saber o tempo de viagem");
            System.out.println("7 - Para saber o Média de consumo de combustivel");
            System.out.println("8 - Para saber a Velocidade Média");
            System.out.println("9 - Para sair do programa");

            opcao = bind.nextInt();

            switch (opcao){

                case 1:

                    Carro.status();

                    break;

                case 2:

                    Carro.ligado();

                    break;

                case 3:

                    Carro.desligado();

                    break;
                case 4:

                    Carro.andar();
                    break;

                case 5:

                    Carro.parar();
                    break;

                case 6:

                    Carro.tempoDeViagem();

                    break;

                case 7:

                    Carro.consumoDeCombustivel();
                    break;

                case 8:

                    Carro.velocidaDaViagem();

                case 9:

                    System.out.println("Fim");

                    break;

            }
        }
    }
}
