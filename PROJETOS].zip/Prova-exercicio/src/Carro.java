import java.util.Scanner;

public class Carro {

    static  int tanque;

    static int velocidade;

    static double distancia;

    static double tempo;

    static boolean motor;

    static double consumo;


     public static void status(){

        System.out.println("Quantidade de combustivel: " + tanque + " Km");
        System.out.println("Média de consumo de combustivel "+ tanque/distancia + " Km/L");
        System.out.println("Distância possível a ser percorrida "+ tanque * 2 + " Km");
        if(motor == true) {
            System.out.println("Estado do carro: Ligado");
        }else{
            System.out.println("Estado do carro: Desligado");
        }

    }

    public static void tempoDeViagem(){

        System.out.println(tempo);
    }

    public static void velocidaDaViagem(){

        double velocidademedia;

        velocidademedia = distancia / tempo;

        System.out.println(velocidademedia + " Km/h");
    }

    static boolean ligado(){

        if(motor == false){

            motor = true;

            System.out.println("O motor ligou");

        }else{

            System.out.println("O motor já esta ligado");
        }

        return motor;

    }

    static boolean desligado(){

        if(motor == true){

            motor = false;
            System.out.println("O motor desligou");
        }else{

            System.out.println("O motor já está desligado");
        }

        return motor;

    }

    public static void  andar() {

        if (motor == true) {

            System.out.println("O carro está andando");

        } else {

            System.out.println("Você não pode anda com carro desligado");

        }
    }

    public static void parar() {

        if (motor == true) {

            System.out.println("O carro parou");

        } else {

            System.out.println( "Você não pode parar um veículo imóvel");

        }
    }

    public static void consumoDeCombustivel(){

        System.out.println("Quantos Litros de Combustivel foi gasto na viagem:");

        Scanner bind = new Scanner(System.in);

        int tanquegasto;

        tanquegasto = bind.nextInt();


       consumo = distancia/(tanque - tanquegasto);

        System.out.println("O consumo de Combustivel está "+ consumo + " Km/L");

    }
}
