import java.sql.SQLOutput;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Pilha pilha = null; // Inicialmente a pilha está vazia

        int opcao;
        do {
            System.out.println("\nMenu:");
            System.out.println("1 - Adicionar valor à pilha");
            System.out.println("2 - Mostrar último valor da pilha");
            System.out.println("3 - Organizar em ordem crescente a pilha");
            System.out.println("4 - Desempilhar o último valor");
            System.out.println("5 - Mostrar pilha completa");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");

            opcao = scanner.nextInt();

            switch (opcao) {
                case 1:
                    if (pilha == null) {
                        pilha = new Pilha(5);
                        System.out.println("Por favor, preencha os 5 valores da pilha:");
                        for (int i = 0; i < 5; i++) {
                            System.out.print("Digite o " + (i + 1) + "º valor: ");
                            int valor = scanner.nextInt();
                            pilha.push(valor);
                        }
                    } else {
                        System.out.print("Digite o valor a ser adicionado à pilha: ");
                        int valor = scanner.nextInt();
                        pilha.push(valor);
                    }
                    break;
                case 2:
                    if (pilha != null) {
                        pilha.peek();
                    } else {
                        System.out.println("A pilha está vazia. Não há valores para mostrar.");
                    }
                    break;
                case 3:
                    if (pilha != null) {
                        pilha.ordenarCrescente();
                    } else {
                        System.out.println("A pilha está vazia. Não há valores para ordenar.");
                    }
                    break;
                case 4:
                    if (pilha != null) {
                        pilha.pop();
                    } else {
                        System.out.println("A pilha está vazia. Não há valores para remover.");
                    }
                    break;
                case 5:
                    if (pilha != null) {
                        pilha.mostrarPilha();
                    } else {
                        System.out.println("A pilha está vazia. Não há valores para mostrar.");
                    }
                    break;
                case 0:
                    System.out.println("Encerrando o programa.");
                    break;
                default:
                    System.out.println("Opção inválida. Por favor, escolha uma opção válida.");
            }
        } while (opcao != 0);

        scanner.close();
    }
}
