import java.util.Scanner;
public class triangulo {

    double a;
    double b;
    double c;

    double calcularArea(){

        double p = (a + b + c) / 2.0;

        return Math.sqrt(p*(p - a)*(p - b)*(p - c));

    }

}
