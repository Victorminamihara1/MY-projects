import java.util.Scanner;
public class produto {

    String nome;

    double preco;

    int quantidade;

    Scanner bind = new Scanner(System.in);

    double totalValorEstoque(){

        return preco * quantidade;

    }

    void addProduto(int quantidade){

        this.quantidade+= quantidade;

    }

    void removerProduto(int quantidade){

        this.quantidade -= quantidade;
    }

}
