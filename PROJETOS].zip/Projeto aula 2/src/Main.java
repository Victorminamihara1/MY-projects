import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner bind = new Scanner(System.in);

        triangulo x, y;

        x = new triangulo();
        y = new triangulo();

        System.out.println(" Informe as medidas do Triangulo");
        x.a = bind.nextDouble();
        x.b = bind.nextDouble();
        x.c = bind.nextDouble();
        System.out.println(" Informe as medidas do Triangulo");
        y.a = bind.nextDouble();
        y.b = bind.nextDouble();
        y.c = bind.nextDouble();

        double areaX = x.calcularArea();
        double areaY = y.calcularArea();

        if (areaX > areaY){
            System.out.println("X maior");
        }else if(areaY > areaX){
            System.out.println("y maior");
        }else{
            System.out.println("iguais");
        }
        bind.close();

    }

    //Exercercio >> fazer uma versão que calcula area de um quardado
}
