public class Caneta {

    String modelo;

    String cor;

    float ponta;

    int carga;

    boolean tampa;
    void Status(){

        System.out.println("Informações da Caneta");
        System.out.println("Modelo da caneta: " + modelo);
        System.out.println("Cor da caneta: " + cor);
        System.out.println("Tipo de ponta da Caneta: " + ponta);
        System.out.println("Quantidade de carga: " + carga);

        if(tampa == true){

            System.out.println("Tampa: Destampado");

        }else{

            tampa = false;
            System.out.println("Tampa: Tampado");
        }

    }
    String Rabiscar(){

        if(tampa == true){

            return "Voce fez um risco";

         }else{

            return "Você não pode rabiscar com a tampa da caneta";

        }
    }
    boolean Tampar() {

        if(tampa == true){

            tampa = false;

        }

        return tampa;
    }

    boolean Destampar(){

    if (tampa == false){

        tampa = true;
    }

        return tampa;
    }

        String Desenhar () {

            if(tampa == true){

                return "Você fez um desenho";

            }else{

                return "Você não pode desenhar com a tampa da caneta";
            }
        }
    }
