import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner bind = new Scanner(System.in);

        Caneta caneta = new Caneta();

        System.out.println("CANETA BIC AZUL");
        System.out.println();
        System.out.println("Informe as informações de sua caneta");
        System.out.println("Tipo de ponta: ");
        caneta.ponta = bind.nextFloat();
        System.out.println("Quantidade de carga: ");
        caneta.carga = bind.nextInt();
        System.out.println("Tipo de cor: ");
        caneta.cor = bind.next();
        System.out.println("Tipo do modelo: ");
        caneta.modelo = bind.next();

        int opcao = 0;
        while(opcao != 9){

            System.out.println("Para fazer qualquer ação com a caneta siga a instrução");
            System.out.println("1 - Ver Status");
            System.out.println("2 - Destampar");
            System.out.println("3 - Tampar");
            System.out.println("4 - Rabiscar");
            System.out.println("5 - Desenhar");
            System.out.println("6 - Fim");

            opcao = bind.nextInt();

            switch (opcao) {


                case 1:

                    caneta.Status();

                    break;

                case 2:

                    caneta.Destampar();

                    break;

                case 3:

                    caneta.Tampar();

                    break;

                case 4:

                    caneta.Rabiscar();

                    break;

                case 5:

                    caneta.Desenhar();

                    break;

                case 6:

                    System.out.print("FIM DAS OPERAÇÕES");

                    break;

            }
        }
    }
}