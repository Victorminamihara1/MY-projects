public class Comissionados extends Funcionario{

    private int vendas;


    public Comissionados(Integer numero, String nome, double salario){
        super(numero, nome, salario);

    }

    public int getVendas() {
        return vendas;
    }


    public void calcularSalario3(double vendas){

        salario = 1500 + (0.02 * (40 * vendas));


    }

}
