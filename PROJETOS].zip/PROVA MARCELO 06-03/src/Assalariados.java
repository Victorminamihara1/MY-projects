public class Assalariados extends Funcionario{

    public Assalariados(Integer numero, String nome, double salario){
        super(numero, nome, salario);

    }

    @Override
    public void calcularSalario(){

        salario = 1500;
    }



}
