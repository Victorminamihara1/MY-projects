import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner bind = new Scanner(System.in);

        System.out.print("Informe número da Conta:");
        int numero = bind.nextInt();
        System.out.print("Informe seu Nome:");
        String nome = bind.next();
        System.out.println("Informe que tipo de Funcionário você é?");
        System.out.println("(AS) Para Assalariado");
        System.out.println("(HO) Para Horistas");
        System.out.println("(CO) Para Comissionados");
        String tipoDeFuncionarios = bind.next();
        double salario = 1500;
        if(tipoDeFuncionarios.equals("AS")){

            Assalariados assalariados = new Assalariados(numero, nome, salario);
            List<Assalariados> lista = new ArrayList<>();
            lista.add(new Assalariados(numero, nome, salario));

            int opcao = 0;
            while (opcao != 3){
                System.out.println("1 - Calcular Salário:");
                System.out.println("2 - Mostrar Informações da Conta:");
                System.out.println("0 - Fim das Operações:");
                opcao = bind.nextInt();

               switch (opcao){
                   case 1:

                    assalariados.calcularSalario();
                    System.out.println("Salario é: " + assalariados.getSalario());
                    System.out.println();
                   break;

                   case 2:
                       System.out.println("Número da Conta: " + assalariados.getNumero());
                       System.out.println("Nome da Conta: " + assalariados.getNome());
                       System.out.println("Salario é: " + assalariados.getSalario());

                       break;

                   case 0:

                       System.out.println("Fim das operações");
                       break;

               }
            }
        }
        if(tipoDeFuncionarios.equals("HO")){

           Horistas horistas = new Horistas(numero, nome, salario);
            List<Horistas> lista = new ArrayList<>();
            lista.add(new Horistas(numero, nome, salario));

            int opcao = 0;
            while (opcao != 3){
                System.out.println("1 - Calcular Salário:");
                System.out.println("2 - Mostrar Informações da Conta:");
                System.out.println("0 - Fim das Operações:");
                opcao = bind.nextInt();

                switch (opcao){
                    case 1:


                        System.out.println("Quantas Horas você trabalhou?");
                        double horasTrabalhas = bind.nextDouble();

                        System.out.println("Quantas Horas Extras você trabalhou?");
                        double horasExtras = bind.nextDouble();
                        Horistas.calcularSalario2(horasTrabalhas, horasExtras);
                        System.out.println("Salario é: " + horistas.getSalario());
                        System.out.println();
                        break;

                    case 2:
                        System.out.println("Número da Conta: " +horistas.getNumero());
                        System.out.println("Nome da Conta: " + horistas.getNome());
                        System.out.println("Salario é: " + horistas.getSalario());

                        break;

                    case 0:

                        System.out.println("Fim das operações");
                        break;

                }
            }


        }
        if(tipoDeFuncionarios.equals("CO")){
            Comissionados comissionados = new Comissionados(numero, nome, salario);
            List<Comissionados> lista = new ArrayList<>();
            lista.add(new Comissionados(numero, nome, salario));

            int opcao = 0;
            while (opcao != 3){
                System.out.println("1 - Calcular Salário:");
                System.out.println("2 - Mostrar Informações da Conta:");
                System.out.println("0 - Fim das Operações:");
                opcao = bind.nextInt();

                switch (opcao){
                    case 1:

                        System.out.println("Quantas Vendas você fez?");
                        double vendas = bind.nextDouble();
                        comissionados.calcularSalario3(vendas);
                        System.out.println("Salario é: " + comissionados.getSalario());
                        System.out.println();
                        break;

                    case 2:
                        System.out.println("Número da Conta: " + comissionados.getNumero());
                        System.out.println("Nome da Conta: " + comissionados.getNome());
                        System.out.println("Salario é: " + comissionados.getSalario());

                        break;

                    case 0:

                        System.out.println("Fim das operações");
                        break;

                }
            }

        }else{

            System.out.println("Não existe esse tipo de Funcionário");
        }
    }
}
