public class Horistas extends Funcionario{

    private double horasTrabalhadas;
    private double horasExtras;

    public Horistas(Integer numero, String nome, double salario){
        super(numero, nome, salario);

    }

    public double getHorasExtras() {
        return horasExtras;
    }

    public void setHorasExtras(double horasExtras) {
        this.horasExtras = horasExtras;
    }


    public double getHorasTrabalhadas() {
        return horasTrabalhadas;
    }

    public void setHorasTrabalhadas(double horasTrabalhadas) {
        this.horasTrabalhadas = horasTrabalhadas;
    }

    public static void calcularSalario2(double horasTrabalhadas, double horasExtras){

        salario = (10 * horasTrabalhadas) + (7 * horasExtras);

    }


}
