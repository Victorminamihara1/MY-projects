public class Funcionario {

    private int numero;

    private String nome;

    protected static double salario;

    public Funcionario(Integer numero, String nome, double salario){
        this.numero = numero;
        this.nome = nome;
        this.salario = salario;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public double getSalario() {
        return salario;
    }

    public void calcularSalario(){

        salario = 0;

    }
}
