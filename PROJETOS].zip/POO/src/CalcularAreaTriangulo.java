import java.util.Scanner;
public class CalcularAreaTriangulo {
}
if (area1 > area2)