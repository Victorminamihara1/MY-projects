import java.util.Scanner;
public class Filme {

     private int codigo;
     private String nome;
     private char genero;
     private double avaliacao;
     private double preco;
     private int anodeLancamento;
     private int duracao;

     private double somaAvaliacao;

     private int totalAvaliacao;

     public Scanner bind = new Scanner(System.in);

     public char getGenero() {
          return genero;
     }

     public void setGenero(char genero) {
          this.genero = genero;
     }

     public double getAvaliacao() {
          return avaliacao;
     }

     public void setAvaliacao(double avaliacao) {
          this.avaliacao = avaliacao;
     }

     public double getPreco() {
          return preco;
     }

     public void setPreco(double preco) {
          this.preco = preco;
     }

     public int getAnodeLancamento() {
          return anodeLancamento;
     }

     public void setAnodeLancamento(int anodeLancamento) {
          this.anodeLancamento = anodeLancamento;
     }

     public int getDuracao() {
          return duracao;
     }

     public void setDuracao(int duracao) {
          this.duracao = duracao;
     }

     public double getSomaAvaliacao() {
          return somaAvaliacao;
     }

     public void setSomaAvaliacao(double somaAvaliacao) {
          this.somaAvaliacao = somaAvaliacao;
     }

     public int getTotalAvaliacao() {
          return totalAvaliacao;
     }

     public void setTotalAvaliacao(int totalAvaliacao) {
          this.totalAvaliacao = totalAvaliacao;
     }

     public String getNome() {

          return nome;
     }

     public void setNome(String nome) {

          this.nome = nome;

     }

     public int getCodigo() {

          return codigo;
     }

     void setCodigo(int codigo) {

          this.codigo = codigo;

     }


     static void Alugar(){

     }
     public void cadastrar(){


     }

     public void pesquisar(){


     }
     void avaliar(double nota){

          avaliacao += nota;
          totalAvaliacao++;

     }

     double mediaAvaliacao(){
          return  avaliacao / (totalAvaliacao + 1);

     }
     public void exibirfichaTecnica(){

         System.out.println("Código do filme: " + codigo);
         System.out.println("Nome do filme: " + nome);



     }
}
