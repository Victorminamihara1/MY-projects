public class Main {
    public static void main(String[] args) {

        Filme filme  = new Filme();

        filme.setNome("JORGEMSSS: " );
        filme.setCodigo(1);
        filme.setGenero('A');
        filme.setAvaliacao(4.5);
        filme.setAnodeLancamento(1972);
        filme.setDuracao(90);

        filme.exibirfichaTecnica();

        filme.avaliar(4.0);
        filme.avaliar(5.0);
        filme.avaliar(4.5);

        System.out.println(filme.getAvaliacao());
        System.out.println(filme.getTotalAvaliacao());
        System.out.println("Média de Avaliação: " + filme.mediaAvaliacao());

    }
}
