import java.util.Scanner;
public class Main {

    public static void main(String[] args) {

        Scanner bind = new Scanner(System.in);

        Leitordenumeros leitordenumeros = new Leitordenumeros();

        System.out.print("Informe o Raio de sua esfera: ");
        leitordenumeros.raio = bind.nextDouble();
        System.out.printf("O volume de sua esfera é: %.2f%n", leitordenumeros.calcularVolume());
        System.out.printf("A circuferência de sua esfera é: %.2f%n", leitordenumeros.calcularCircuferencia());
        System.out.printf("O raio de sua esfera é: %.2f%n", leitordenumeros.raio);
        System.out.printf("O valor de pi é: %.2f%n", leitordenumeros.pi);


    }
}
