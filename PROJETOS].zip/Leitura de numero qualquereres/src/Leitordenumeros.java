public class Leitordenumeros {

    double raio;

    double circuferencia;

    double volume;

    double pi = 3.14;

    double calcularVolume(){

        return volume = 4.0/3.0*pi*Math.pow(raio,3);

    }
    double calcularCircuferencia(){

        return circuferencia = raio*2;
    }
}
