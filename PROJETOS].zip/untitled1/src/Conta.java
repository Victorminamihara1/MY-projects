public class Conta {

    private Integer numero;

    private String nome;

    protected double saldo;

    public Conta(Integer numero, String nome, double saldo) {
        this.numero = numero;
        this.nome = nome;
        this.saldo = saldo;
    }

    public Conta(Integer numero, String nome) {
        this.numero = numero;
        this.nome = nome;
    }

    public Integer getNumero() {
        return numero;
    }

    public void setNumero(Integer numero) {
        this.numero = numero;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSaldo() {
        return saldo;
    }

    /*public void setSaldo(double saldo) {
        this.saldo = saldo;
    }*/

    public void saque(double quantia){

        saldo -= quantia + 5.0;

    }

    public void deposito(double quantia){

        saldo += quantia;
    }

    public String toString() {
        return "Informe o número da conta: "
                +numero
                +", \nNome do titular: "
                +nome
                +", \nInforme o saldo: "
                +saldo;
    }
}
