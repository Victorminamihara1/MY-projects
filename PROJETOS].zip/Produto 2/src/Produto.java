

public class Produto {
    private String nome;
    private double preco;
    private int quantidade;

    public Produto(String nome, double preco, int quantidade){
        this.nome  = nome;
        this.preco = preco;
        this.quantidade = quantidade;
    }

    //Construtor 2

    public Produto (String nome, double preco){
        this.nome  = nome;
        this.preco = preco;

    }

    public  Produto (){

    }
    //Criar metodos acessores
    public void setNome(String nome){
        this.nome = nome;

    }
    public void setPreco(double preco){
        this.preco = preco;
    }

    public void setQuantidade(int quantidade){
        this.quantidade = quantidade;
    }
    public double totalValorEstoque() {
        return preco * quantidade;
    }
    public void addProduto(int quantidade) {
        this.quantidade += quantidade;
    }

    public String getNome(){
        return nome;
    }

    public double getPreco(){
        return preco;
    }

    public int getQuantidade(){
        return quantidade;
    }

    //setters



    public void removerProduto(int quantity) {
        this.quantidade -= quantity;
    }

    public String toString() {
        return "Nome do Produto: "+ nome
                + "\n Preço: R$"
                + String.format("%.2f", preco)
                + "\n Quantidade: "
                + quantidade
                + " unidades\n Total em Estoque: R$"
                + String.format("%.2f", totalValorEstoque());
    }

}

