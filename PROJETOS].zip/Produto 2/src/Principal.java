

import java.util.Scanner;

public class Principal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        //Produto produto = new Produto();

        System.out.println("Entre com os dados do Produto: ");
        System.out.print("Nome: ");
        String nome= sc.nextLine();
        System.out.print("Preço: ");
        double preco = sc.nextDouble();
        System.out.print("Quantidade: ");
        int quantidade = sc.nextInt();

        Produto produto = new Produto(nome, preco, quantidade);
        Produto p = new Produto(nome, preco);

        System.out.println(produto);
        produto.setNome("computador");
        produto.setPreco(1000.0);
        produto.setQuantidade(5);

        System.out.println(produto.getNome());
        System.out.println(produto.getPreco());
        System.out.println(produto.getQuantidade());

 /*
        System.out.println("Dados do p: " + p);

        System.out.println();
        System.out.println("Dados do Produto: " + produto);
        System.out.println();

        System.out.print("Insira a quantidade de produtos a serem adicionados em estoque: ");
        /*int*/ quantidade = sc.nextInt();
        produto.addProduto(quantidade);
        System.out.println();


        System.out.println("Dados atualizados: " + produto);
        System.out.println();
        System.out.print("Insira a quantidade de produtos a serem retirados do estoque: ");
        quantidade = sc.nextInt();
        produto.removerProduto(quantidade);
        System.out.println();
        System.out.println("Dados atualizados: " + produto);


        sc.close();
    }
}

