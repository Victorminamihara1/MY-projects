import java.util.Scanner;

public class Calc1 {


     static void adicao(){

        Scanner bind = new Scanner(System.in);


        double soma;
        System.out.print("Insira primeiro número: ");
        double x = bind.nextDouble();
        System.out.print("Insira segundo  número: ");
        double y = bind.nextDouble();

        soma = x + y;
        System.out.printf("A soma é: %.2f%n", soma);

    }

    public static void main(String[] args) {

        Calc1.adicao();

     }
}
