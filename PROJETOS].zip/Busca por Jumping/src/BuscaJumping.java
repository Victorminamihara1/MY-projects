public class BuscaJumping {S
    public static int busca(int[] array, int alvo) {
        int tamanho = array.length;
        int salto = (int) Math.floor(Math.sqrt(tamanho));
        int passo = 0;  

        while (passo < tamanho && array[Math.min(salto, tamanho) - 1] < alvo) {
            passo += salto;
        }

        int anterior = Math.min(salto, tamanho);
        int atual = Math.min(passo, tamanho);


        for (int i = anterior; i < atual; i++) {
            if (array[i] == alvo) {
                return i;
            }
        }

        return -1;
    }

    public static void main(String[] args) {
        int[] array = {10, 20, 30, 40, 50, 60, 70, 80, 90, 100};
        int alvo = 50;
        int indice = busca(array, alvo);

        if (indice != -1) {
            System.out.println("Elemento encontrado no índice: " + indice);
        } else {
            System.out.println("Elemento não encontrado no array.");
        }
    }
}
