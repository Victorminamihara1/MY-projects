
public class MatematicaD {

    int x;

    int y;

        void funcaoE () {

        if ((x == 1 & y == 1)) {

            System.out.println("--A combinação de A e B é verdadeiro--");

        } else if ((x == 0 & y == 0)) {

            System.out.println("--A combinação de A e B é falso--");

        } else if (x == 1 & y == 0) {

            System.out.println("--A combinação de A e B é falso--");

        } else if (x == 0 & y == 1) {

            System.out.println("--A combinação de A e B é falso--");

            }
        }


        void funcaoOu(){
        if ((x == 1 & y == 1)) {

            System.out.println("--A combinação de A ou B é verdadeiro--");

        } else if ((x == 0 & y == 0)) {

            System.out.println("--A combinação de A ou B é falso--");

        } else if (x == 1 & y == 0) {

            System.out.println("--A combinação de A ou B é verdadeiro--");

        } else if (x == 0 & y == 1) {

            System.out.println("--A combinação de A ou B é verdadeiro--");

        }
    }


        void funcaoCondicional(){

        if ((x == 1 & y == 1)) {

            System.out.println("--A combinação de A condional B é verdadeiro--");

        } else if ((x == 0 & y == 0)) {

            System.out.println("--A combinação de A condicional B é Verdadeiro--");

        } else if (x == 1 & y == 0) {

            System.out.println("--A combinação de A condicional B é falso--");

        } else if (x == 0 & y == 1) {

            System.out.println("--A combinação de A condicional B é verdadeiro--");

        }
    }
}

