import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner bind = new Scanner(System.in);

        MatematicaD matematicaD = new MatematicaD();

        System.out.println("LEMBRE-SE");
        System.out.println();
        System.out.println("O valor lógico para  falso  é ( 0 ): ");
        System.out.println("O valor lógico para verdade é ( 1 ): ");
        System.out.println();
        System.out.print("Insira o valor lógico de A: ");
        matematicaD.x = bind.nextInt();
        System.out.print("Insira o valor lógico de B: ");
        matematicaD.y = bind.nextInt();
        System.out.println("Agora nos informe o tipo de operação lógica");
        System.out.println();

        int opcao = 0;

        while(opcao != 9){

            System.out.println("Para   operação   lógica   ( e )    digite   ( 1 ): ");
            System.out.println("Para   operação   lógica   ( ou )   digite   ( 2 ): ");
            System.out.println("Para operação lógica ( condicional )  digite ( 3 ): ");
            System.out.println("Para finalizar  a  operação  lógica  digite  ( 9 ): ");
            System.out.println();

            opcao = bind.nextInt();

            switch (opcao){

                case 1:
                    matematicaD.funcaoE();

                    break;

                case 2:
                    matematicaD.funcaoOu();

                    break;

                case 3:
                    matematicaD.funcaoCondicional();

                    break;

                case 9:
                    System.out.println("Fim das operações");
                    break;
            }
        }
    }
}
