public class Main {
    public static void main(String[] args) {

        Dog cao = new Dog();

        cao.lantindo();
        cao.comendo();

    }
}