public class Dog extends Animal{

    String raca;



    void lantindo(){

        System.out.println("O cachorro está latindo!");
    }
}
