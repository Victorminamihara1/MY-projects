
public class Animal {

    String nome;

    int idade;

    void comendo(){
        System.out.println("Animal comendo!");

    }
}
