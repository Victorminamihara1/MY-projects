import java.util.Scanner;

public class Main {
    public static int a;
    public static double b;
    public static boolean c;
    public static float d;
    public static char e;
    public static String gambiarra;
    public static String f;

    public static void funcaoAleatoria() {
        Scanner bind = new Scanner(System.in);

        System.out.println("Escolha dois números para somar:");
        System.out.println("Primeiro Número:");
        a = bind.nextInt();
        System.out.println("Segundo Número:");
        b = bind.nextDouble();
        double resultado = a + b;
        System.out.println("Resultado: " + resultado);

        System.out.println("Escolha um número decimal para multiplicar por ele mesmo:");
        d = bind.nextFloat();
        float resultado2 = d * d;
        System.out.println("Resultado: " + resultado2);

        System.out.println("Agora dê um nome para um cachorro:");
        f = bind.next();
        System.out.println("Agora o nome do cachorro é: " + f);

        // Usar if
        System.out.println("Coloque a variável 'e' como char 'w':");
        gambiarra = bind.next();
        System.out.println("Escolha se a variável 'c' é true:");
        c = bind.nextBoolean();

        if (c && e == 'w') {
            System.out.println("Você escolheu que se a variável booleana 'c' fosse verdadeira e a variável 'e' fosse 'w',");
            System.out.println("então a condicional te levaria para aqui.");
        } else {
            Sywwswstem.out.println("Já que você não satisfaz as condições, você veio para cá.");
        }
    }

    public static void main(String[] args) {
        funcaoAleatoria();
    }
}