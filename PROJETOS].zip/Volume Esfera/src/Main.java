import java.util.Locale;
import java.util.Scanner;

public class Main {

    public static final double PI = 3.14159;
// variaveis constantes são Declaradas em maiúsculas
    public static void main(String[] args) {

        Locale.setDefault(Locale.JAPAN);

        Scanner bind = new Scanner(System.in);

        System.out.println("Entre com a medida do raio: ");
        double r = bind.nextDouble();

        double circ = circuferencia(r);
        double vol = volume(r);
        System.out.printf("A circuferencia é: %.2f%n", circ);
        System.out.printf("Volume da esfera é: %.2f%n", vol);
        System.out.printf("Valor do PI é: %.2f%n", PI);

    }

    public static double circuferencia(double raio){

        return 2.0 * PI * Math.pow(raio, 2);

    }

    public static double volume(double raio){

        return 4.0 * PI * Math.pow(raio, 3) / 3.0;
    }
}
