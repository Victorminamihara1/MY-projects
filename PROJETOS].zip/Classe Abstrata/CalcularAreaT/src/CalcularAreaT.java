import java.util.Scanner;

public class CalcularAreaT{
    static Scanner teclado = new Scanner(System.in);
    public static void triangulo() {

        System.out.println("Informe os valores dos lados dos dois triângulos");
        System.out.println("lado A do triangulo 1:");
        double ladoA1 = teclado.nextDouble();
        System.out.println("lado B do triangulo 1:");
        double ladoB1 = teclado.nextDouble();
        System.out.println("lado C do triangulo 1:");
        double ladoC1 = teclado.nextDouble();

        double semiperimetro1 = (ladoA1 + ladoB1 + ladoC1) / 2;
        double area1 = Math.sqrt(semiperimetro1 * (semiperimetro1 - ladoA1) * (semiperimetro1 - ladoB1) * (semiperimetro1 - ladoC1));

        System.out.println("lado A do triangulo 2:");
        double ladoA2 = teclado.nextDouble();
        System.out.println("lado B do triangulo 2:");
        double ladoB2 = teclado.nextDouble();
        System.out.println("lado C do triangulo 2:");
        double ladoC2 = teclado.nextDouble();

        double semiperimetro2 = (ladoA2 + ladoB2 + ladoC2) / 2;
        double area2 = Math.sqrt(semiperimetro2 * (semiperimetro2 - ladoA2) * (semiperimetro2 - ladoB2) * (semiperimetro2 - ladoC2));

        System.out.println("A área do triângulo A é " + area1);
        System.out.println("A área do triângulo B é " + area2);
        if (area1 > area2){
            System.out.println("A área do triângulo A é maior que a área do triângulo B");
        } else if (area2 > area1){
            System.out.println("A área do triângulo B é maior que a área do triângulo A");
        }else {
            System.out.println("Os trinagulos são iguais");


        }
    }
    public static void main(String[] args) {

        triangulo();
    }
}
