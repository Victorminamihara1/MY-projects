public class ContaPoupanca extends Conta{

    static double limiteEmprestimo;

    public ContaPoupanca(int number, double saldo, String titular, double limiteEmprestimo){
        super(number,saldo,titular);
        this.limiteEmprestimo = limiteEmprestimo;
    }

    public static void emprestimo(double quantia, double valor){

        quantia = limiteEmprestimo


    }
}
