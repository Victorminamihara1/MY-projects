public abstract class Conta {
    public static  int number;

    public static String titular;

   public static double saldo;

   public static void saque(double quantia, double valor){

       saldo = saldo - quantia;

   }

   public static void deposito(double quantia){

       saldo = saldo + quantia;

   }

   public Conta(int number, double saldo, String titular){

       this.number = Conta.number;
       this.titular = Conta.titular;
   }
}
