public class ContaPJ extends Conta{
    static double taxaDeJuros;


    public ContaPJ(int number, double saldo, String titular, double taxaDeJuros){

    }

    public static void atualizar(){


    }
}
