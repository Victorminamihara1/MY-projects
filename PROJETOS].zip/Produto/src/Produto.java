import java.util.Scanner;
public class Produto {

    String nome;

    double preco;

    int quantidade;

    Scanner bind = new Scanner(System.in);

    double totalValorEstoque(){

        return preco * quantidade;

    }

    void addProduto(int quantidade){

        this.quantidade+= quantidade;

    }

    void removerProduto(int quantidade){

        this.quantidade -= quantidade;
    }

    public String toString() {

        return "\nNome do Produto: " + nome
                + ", Preço: R$" + String.format("%.2f", preco)
                + ", Quantidade: " + quantidade + " unidades."
                + " \nTotal do Estoque = R$"
                + String.format("%.2f",totalValorEstoque());
    }

}
