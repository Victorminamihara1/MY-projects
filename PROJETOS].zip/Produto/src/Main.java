import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner bind = new Scanner(System.in);

        Produto produto = new  Produto();

        System.out.println("Entre com os dados no Produto: ");
        System.out.print("Nome: ");
        produto.nome = bind.nextLine();
        System.out.print("Preço: ");
        produto.preco = bind.nextDouble();
        System.out.print("Quantidade: ");
        produto.quantidade = bind.nextInt();

        System.out.println("Dados do Produto: " + produto);

        System.out.print("Insira a quantidade de produtos a serem adicionados no estoque: ");

        int qnt = bind.nextInt();
        produto.addProduto(qnt);
        System.out.println("Dados atualizados: " + produto);

        System.out.println("Insira a quantidade de produto a serem removidos do estoque: " );
        qnt = bind.nextInt();
        produto.removerProduto(qnt);
        System.out.println("Dados Atuliazados: " + produto);

    }
}