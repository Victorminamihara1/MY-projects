public class Calculadora {

    public static final double PI = 3.14159;

    public static double circuferencia(double raio){

        return 2.0 * PI * Math.pow(raio, 2);

    }

    public static double volume(double raio){

        return 4.0 * PI * Math.pow(raio, 3) / 3.0;
    }
}
