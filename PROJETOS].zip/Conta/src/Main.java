import java.util.ArrayList;
import java.util.List;

public class Main{
    public static void main(String[] args) {

        ContaPJ contapj = new ContaPJ(1002, "UNIFIL", 0.0, 1000.0);

        //UPCASTING > quando temos algo da subclasse para a superclasse
        Conta conta1 = contapj;
        //conta1.getSaldo();

        Conta conta2 = new ContaPJ(1003, "Bobs", 0.0, 500.0);
        Conta conta3 = new ContaPoupanca(1004, "Cida", 0.0, 0.02);


        List<Conta> lista = new ArrayList<>();

        lista.add(new ContaPJ(1002, "UNIFIL", 220.0, 400.0));
        lista.add(new ContaPJ(1003, "UNIFIL", 330.0, 1000.0));
        lista.add(new ContaPoupanca(1004, "UNIFIL", 70.0, 0.2));
        lista.add(new ContaPoupanca(1005, "UNIFIL", 980.0, 0.2));


        double soma = 0.0;
        for(Conta cc : lista){
            soma += cc.getSaldo();
        }
        System.out.printf("Total dos Saldos em conta: %.2f%n", soma);

        for(Conta cc : lista){
            cc.deposito(100);
        }
        for(Conta cc : lista){
            soma += cc.getSaldo();
        }
        System.out.printf("Total dos Saldos em conta: %.2f%n", soma);

        for(Conta cc : lista){
            System.out.printf("Nomes dos Usuários: %.2f%n", );
            cc.getNome();
        }
    }
}