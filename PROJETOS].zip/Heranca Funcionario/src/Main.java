import java.util.Scanner;
public class Main {
    public static void main(String[] args) {

        Scanner bind = new Scanner(System.in);

        Funcionario funcionario = new Funcionario();

        System.out.println("Informe os dados");
        System.out.print("Nome: ");
        funcionario.nome = bind.nextLine();
        System.out.print("Infome o salario bruto: ");
        funcionario.salario = bind.nextDouble();
        System.out.print("Informe o valor do imposto: ");
        funcionario.imposto = bind.nextDouble();

        System.out.println();
        System.out.println("Funcionario: " + funcionario);
        System.out.println();
        System.out.println("Informe a porcentagem de aumento: ");
        double porcentagem = bind.nextDouble();
        funcionario.aumentarSalario(porcentagem);
        System.out.println();
        System.out.println("Dados Atualizados: "  + funcionario);
    }
}